package sg.edu.rp.c346.id19040088.billplease;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    //Declare variables
   EditText amount;
   EditText numPax;
   ToggleButton svs;
   ToggleButton gst;
   TextView tbill;
   TextView ebill;
   Button split;
   Button reset;
   EditText disc;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        amount = findViewById(R.id.AmtInput);
        numPax = findViewById(R.id.PaxInput);
        tbill = findViewById(R.id.totalBill);
        ebill = findViewById(R.id.eachPay);
        svs = findViewById(R.id.svs);
        gst = findViewById(R.id.gst);
        split = findViewById(R.id.split);
        reset = findViewById(R.id.reset);
        disc = findViewById(R.id.discInput);

        split.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Calculation of Bill
                if (amount.getText().toString().length() != 0 && numPax.getText().toString().length() != 0) {
                    double calcAmt = 0.0;
                    if (!svs.isChecked() && !gst.isChecked()) {
                        calcAmt = Double.parseDouble(amount.getText().toString());
                    } else if (svs.isChecked() && !gst.isChecked()) {
                        calcAmt = Double.parseDouble(amount.getText().toString()) * 1.1;
                    } else if (!svs.isChecked() && gst.isChecked()) {
                        calcAmt = Double.parseDouble(amount.getText().toString()) * 1.07;
                    } else {
                        calcAmt = Double.parseDouble(amount.getText().toString()) * 1.17;
                    }

                    if (disc.getText().toString().length() != 0) {
                        calcAmt = 1 - Double.parseDouble(disc.getText().toString()) / 100;
                    }

                    tbill.setText("Total Bill: $" + String.format("%.2f", calcAmt));
                    //Num of Pax
                    int count = Integer.parseInt(numPax.getText().toString());
                    //Price per pax
                    if (count != 1) {
                        ebill.setText("Each Pays: $" + String.format("%.2f", calcAmt));
                    } else {
                        ebill.setText("Each Pays: $" + calcAmt);
                    }

                }
                reset.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        amount.setText("");
                        numPax.setText("");
                        svs.setChecked(false);
                        gst.setChecked(false);
                        disc.setText("");
                    }
                });
            }
        });



    }
}
